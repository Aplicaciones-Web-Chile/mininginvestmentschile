import React from 'react';
import { useTranslation } from 'react-i18next';
import { LanguageSwitch } from './components/LanguageSwitch';
import { AnimatedSection } from './components/AnimatedSection';
import { ChevronDown, Mail, Phone, Calendar, MapPin, Shield, Hammer, HardHat, FileCheck, Building2 } from 'lucide-react';

function App() {
  const { t } = useTranslation();

  const services = [
    { icon: FileCheck, text: t('services.service1') },
    { icon: Building2, text: t('services.service2') },
    { icon: Shield, text: t('services.service3') },
    { icon: HardHat, text: t('services.service4') },
    { icon: Hammer, text: t('services.service5') },
  ];

  return (
    <div className="min-h-screen bg-dark text-white">
      {/* Header */}
      <header className="fixed w-full bg-dark/90 backdrop-blur-sm z-50">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4">
            <img src="/logo.png" alt="Meza & Pierre" className="h-12" />
            <h1 className="text-2xl font-bold text-primary">Meza & Pierre</h1>
          </div>
          <div className="flex items-center gap-8">
            <a href="#services" className="hover:text-primary transition-colors">Services</a>
            <a href="#projects" className="hover:text-primary transition-colors">Projects</a>
            <a href="#about" className="hover:text-primary transition-colors">About</a>
            <a href="#contact" className="hover:text-primary transition-colors">Contact</a>
            <LanguageSwitch />
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center text-center"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url(/pexels-apasaric-1238864.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}>
        <AnimatedSection className="max-w-4xl mx-auto px-6">
          <h1 className="text-5xl font-bold mb-6">{t('hero.title')}</h1>
          <p className="text-xl text-white/80 mb-8">{t('hero.subtitle')}</p>
          <a href="#projects" 
            className="inline-flex items-center gap-2 px-8 py-3 bg-primary text-dark font-semibold rounded-lg hover:bg-secondary transition-colors">
            {t('hero.cta')}
            <ChevronDown />
          </a>
        </AnimatedSection>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-dark-light">
        <AnimatedSection className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">{t('services.title')}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="p-6 bg-dark rounded-lg border border-primary/20 hover:border-primary/40 transition-colors">
                <service.icon className="w-12 h-12 text-primary mb-4" />
                <p className="text-lg">{service.text}</p>
              </div>
            ))}
          </div>
        </AnimatedSection>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20">
        <AnimatedSection className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">{t('projects.title')}</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {[1, 2].map((projectNum) => (
              <div key={projectNum} className="bg-dark-light p-8 rounded-lg">
                <h3 className="text-xl font-semibold mb-4">{t(`projects.project${projectNum}.title`)}</h3>
                <p className="text-white/80 mb-2">{t(`projects.project${projectNum}.reserves`)}</p>
                {projectNum === 1 && (
                  <p className="text-white/80 mb-2">{t(`projects.project${projectNum}.certification`)}</p>
                )}
                {projectNum === 2 && (
                  <p className="text-white/80 mb-2">{t(`projects.project${projectNum}.area`)}</p>
                )}
                <p className="text-primary font-semibold mb-4">{t(`projects.project${projectNum}.price`)}</p>
                <button className="w-full py-2 px-4 bg-primary/10 text-primary border border-primary/20 rounded hover:bg-primary/20 transition-colors">
                  {t('projects.requestInfo')}
                </button>
              </div>
            ))}
          </div>
        </AnimatedSection>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-dark-light">
        <AnimatedSection className="container mx-auto px-6 max-w-3xl text-center">
          <h2 className="text-3xl font-bold mb-8">{t('about.title')}</h2>
          <p className="text-lg text-white/80">{t('about.content')}</p>
        </AnimatedSection>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <AnimatedSection className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-4">{t('contact.title')}</h2>
          <p className="text-center text-white/80 mb-12">{t('contact.subtitle')}</p>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <Mail className="text-primary" />
                <a href="mailto:patrice@mininginvestmentschile.com" className="hover:text-primary transition-colors">
                  patrice@mininginvestmentschile.com
                </a>
              </div>
              <div className="flex items-center gap-4">
                <Phone className="text-primary" />
                <a href="tel:+56987605326" className="hover:text-primary transition-colors">
                  +56 9 8760 5326
                </a>
              </div>
              <div className="flex items-center gap-4">
                <Calendar className="text-primary" />
                <button className="hover:text-primary transition-colors">
                  {t('contact.schedule')}
                </button>
              </div>
              <div className="flex items-center gap-4">
                <MapPin className="text-primary" />
                <span>Santiago, Chile</span>
              </div>
            </div>

            <form className="space-y-6">
              <input
                type="text"
                placeholder={t('contact.name')}
                className="w-full p-3 bg-dark-light border border-primary/20 rounded-lg focus:border-primary outline-none"
              />
              <input
                type="email"
                placeholder={t('contact.email')}
                className="w-full p-3 bg-dark-light border border-primary/20 rounded-lg focus:border-primary outline-none"
              />
              <textarea
                placeholder={t('contact.message')}
                rows={4}
                className="w-full p-3 bg-dark-light border border-primary/20 rounded-lg focus:border-primary outline-none"
              />
              <button
                type="submit"
                className="w-full py-3 bg-primary text-dark font-semibold rounded-lg hover:bg-secondary transition-colors"
              >
                {t('contact.submit')}
              </button>
            </form>
          </div>
        </AnimatedSection>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-dark-light border-t border-primary/20">
        <div className="container mx-auto px-6 text-center">
          <p className="text-white/60 max-w-2xl mx-auto mb-4 text-sm">{t('footer.disclaimer')}</p>
          <p className="text-white/80 mb-2">{t('footer.copyright')}</p>
          <p className="text-white/60 text-sm">
            Desarrollado por <a href="http://www.aplicacionesweb.cl" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-secondary transition-colors">AplicacionesWeb</a>
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;