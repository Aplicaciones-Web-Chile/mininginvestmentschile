export const resources = {
  en: {
    translation: {
      hero: {
        title: "Mining Investment with a Global Vision",
        subtitle: "Over 10 years connecting mining projects with international investors.",
        cta: "View Available Projects"
      },
      services: {
        title: "What We Offer",
        service1: "Review and evaluation of mining projects",
        service2: "Project management and engineering",
        service3: "Fire protection systems",
        service4: "Labor training and mining safety",
        service5: "Brokerage and advisory for investors seeking to buy deposits"
      },
      projects: {
        title: "Available Projects",
        requestInfo: "Request Information",
        project1: {
          title: "Copper-Gold-Silver Project – Río Hurtado",
          reserves: "Estimated reserves: ~34 million tons",
          certification: "NI 43-101 Certification",
          price: "USD 30,000,000"
        },
        project2: {
          title: "Gold-Copper-Silver Project – Petorca",
          area: "700 hectares, legally constituted",
          reserves: "Reserves: 38,000 ton proven, 107,000 ton inferred",
          price: "USD 3,000,000"
        }
      },
      about: {
        title: "About Us",
        content: "Meza & Pierre has been active in the mining industry for over a decade. Our trilingual team (ES-FR-EN) provides brokerage services, deposit evaluations, and strategic advisory."
      },
      contact: {
        title: "Interested in investing or learning more about our projects?",
        subtitle: "Contact us to receive our full deposit portfolio.",
        name: "Name",
        email: "Email",
        message: "Message",
        submit: "Send Message",
        schedule: "Schedule a Meeting"
      },
      footer: {
        disclaimer: "Information contained on this site is referential and subject to confirmation in a meeting with Meza & Pierre. Exact mine locations are not disclosed.",
        copyright: "© Meza & Pierre. All Rights Reserved."
      }
    }
  },
  es: {
    translation: {
      hero: {
        title: "Inversión minera con visión global",
        subtitle: "Más de 10 años conectando proyectos mineros con inversionistas internacionales",
        cta: "Ver Proyectos Disponibles"
      },
      services: {
        title: "¿Qué ofrecemos?",
        service1: "Revisión y evaluación de proyectos mineros",
        service2: "Gestión de proyectos e ingeniería",
        service3: "Sistemas de protección contra incendios",
        service4: "Formación laboral y seguridad minera",
        service5: "Corretaje y asesoría a inversionistas en la compra de yacimientos"
      },
      projects: {
        title: "Proyectos Disponibles",
        requestInfo: "Solicitar Información",
        project1: {
          title: "Proyecto Cobre-Oro-Plata – Río Hurtado",
          reserves: "Reservas estimadas: ~34 millones de toneladas",
          certification: "Certificación NI 43-101",
          price: "USD 30,000,000"
        },
        project2: {
          title: "Proyecto Oro-Cobre-Plata – Petorca",
          area: "700 ha mineras constituidas",
          reserves: "Reservas: 38.000 ton determinadas, 107.000 ton inferidas",
          price: "USD 3,000,000"
        }
      },
      about: {
        title: "Sobre Nosotros",
        content: "Meza & Pierre ha estado presente en la industria minera por más de una década. Nuestro equipo trilingüe (ES-FR-EN) ofrece servicios de corretaje, evaluación de yacimientos y asesoría estratégica."
      },
      contact: {
        title: "¿Interesado en invertir o conocer más de nuestros proyectos?",
        subtitle: "Contáctanos para recibir la carpeta de yacimientos.",
        name: "Nombre",
        email: "Correo",
        message: "Mensaje",
        submit: "Enviar Mensaje",
        schedule: "Programar Reunión"
      },
      footer: {
        disclaimer: "La información contenida en este sitio es referencial y sujeta a confirmación en reunión con Meza & Pierre. No se divulga la dirección exacta de las minas.",
        copyright: "© Meza & Pierre. Todos los derechos reservados."
      }
    }
  }
};