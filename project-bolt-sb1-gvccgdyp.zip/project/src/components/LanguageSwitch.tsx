import { Globe } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export const LanguageSwitch = () => {
  const { i18n } = useTranslation();

  const toggleLanguage = () => {
    i18n.changeLanguage(i18n.language === 'en' ? 'es' : 'en');
  };

  return (
    <button
      onClick={toggleLanguage}
      className="flex items-center gap-2 px-4 py-2 text-white/80 hover:text-white transition-colors"
    >
      <Globe size={20} />
      <span className="font-medium">{i18n.language.toUpperCase()}</span>
    </button>
  );
};